document.getElementById("test").addEventListener("click", test);

function test() {
    $("#search").val("testing");
    $("#search").submit();
}


