;(function(){

    /**
     * Require the given path.
     *
     * @param {String} path
     * @return {Object} exports
     * @api public
     */
    
    function require(path, parent, orig) {
      var resolved = require.resolve(path);
    
      // lookup failed
      if (null == resolved) {
        orig = orig || path;
        parent = parent || 'root';
        var err = new Error('Failed to require "' + orig + '" from "' + parent + '"');
        err.path = orig;
        err.parent = parent;
        err.require = true;
        throw err;
      }
    
      var module = require.modules[resolved];
    
      // perform real require()
      // by invoking the module's
      // registered function
      if (!module._resolving && !module.exports) {
        var mod = {};
        mod.exports = {};
        mod.client = mod.component = true;
        module._resolving = true;
        module.call(this, mod.exports, require.relative(resolved), mod);
        delete module._resolving;
        module.exports = mod.exports;
      }
    
      return module.exports;
    }
    
    /**
     * Registered modules.
     */
    
    require.modules = {};
    
    /**
     * Registered aliases.
     */
    
    require.aliases = {};
    
    /**
     * Resolve `path`.
     *
     * Lookup:
     *
     *   - PATH/index.js
     *   - PATH.js
     *   - PATH
     *
     * @param {String} path
     * @return {String} path or null
     * @api private
     */
    
    require.resolve = function(path) {
      if (path.charAt(0) === '/') path = path.slice(1);
    
      var paths = [
        path,
        path + '.js',
        path + '.json',
        path + '/index.js',
        path + '/index.json'
      ];
    
      for (var i = 0; i < paths.length; i++) {
        var path = paths[i];
        if (require.modules.hasOwnProperty(path)) return path;
        if (require.aliases.hasOwnProperty(path)) return require.aliases[path];
      }
    };
    
    /**
     * Normalize `path` relative to the current path.
     *
     * @param {String} curr
     * @param {String} path
     * @return {String}
     * @api private
     */
    
    require.normalize = function(curr, path) {
      var segs = [];
    
      if ('.' != path.charAt(0)) return path;
    
      curr = curr.split('/');
      path = path.split('/');
    
      for (var i = 0; i < path.length; ++i) {
        if ('..' == path[i]) {
          curr.pop();
        } else if ('.' != path[i] && '' != path[i]) {
          segs.push(path[i]);
        }
      }
    
      return curr.concat(segs).join('/');
    };
    
    /**
     * Register module at `path` with callback `definition`.
     *
     * @param {String} path
     * @param {Function} definition
     * @api private
     */
    
    require.register = function(path, definition) {
      require.modules[path] = definition;
    };
    
    /**
     * Alias a module definition.
     *
     * @param {String} from
     * @param {String} to
     * @api private
     */
    
    require.alias = function(from, to) {
      if (!require.modules.hasOwnProperty(from)) {
        throw new Error('Failed to alias "' + from + '", it does not exist');
      }
      require.aliases[to] = from;
    };
    
    /**
     * Return a require function relative to the `parent` path.
     *
     * @param {String} parent
     * @return {Function}
     * @api private
     */
    
    require.relative = function(parent) {
      var p = require.normalize(parent, '..');
    
      /**
       * lastIndexOf helper.
       */
    
      function lastIndexOf(arr, obj) {
        var i = arr.length;
        while (i--) {
          if (arr[i] === obj) return i;
        }
        return -1;
      }
    
      /**
       * The relative require() itself.
       */
    
      function localRequire(path) {
        var resolved = localRequire.resolve(path);
        return require(resolved, parent, path);
      }
    
      /**
       * Resolve relative to the parent.
       */
    
      localRequire.resolve = function(path) {
        var c = path.charAt(0);
        if ('/' == c) return path.slice(1);
        if ('.' == c) return require.normalize(p, path);
    
        // resolve deps by returning
        // the dep in the nearest "deps"
        // directory
        var segs = parent.split('/');
        var i = lastIndexOf(segs, 'deps') + 1;
        if (!i) i = 0;
        path = segs.slice(0, i + 1).join('/') + '/deps/' + path;
        return path;
      };
    
      /**
       * Check if module is defined at `path`.
       */
    
      localRequire.exists = function(path) {
        return require.modules.hasOwnProperty(localRequire.resolve(path));
      };
    
      return localRequire;
    };
    require.register("component-event/index.js", function(exports, require, module){
    var bind = window.addEventListener ? 'addEventListener' : 'attachEvent',
        unbind = window.removeEventListener ? 'removeEventListener' : 'detachEvent',
        prefix = bind !== 'addEventListener' ? 'on' : '';
    
    /**
     * Bind `el` event `type` to `fn`.
     *
     * @param {Element} el
     * @param {String} type
     * @param {Function} fn
     * @param {Boolean} capture
     * @return {Function}
     * @api public
     */
    
    exports.bind = function(el, type, fn, capture){
      el[bind](prefix + type, fn, capture || false);
    
      return fn;
    };
    
    /**
     * Unbind `el` event `type`'s callback `fn`.
     *
     * @param {Element} el
     * @param {String} type
     * @param {Function} fn
     * @param {Boolean} capture
     * @return {Function}
     * @api public
     */
    
    exports.unbind = function(el, type, fn, capture){
      el[unbind](prefix + type, fn, capture || false);
    
      return fn;
    };
    });
    require.register("component-delegate/index.js", function(exports, require, module){
    
    /**
     * Module dependencies.
     */
    
    var matches = require('matches-selector')
      , event = require('event');
    
    /**
     * Delegate event `type` to `selector`
     * and invoke `fn(e)`. A callback function
     * is returned which may be passed to `.unbind()`.
     *
     * @param {Element} el
     * @param {String} selector
     * @param {String} type
     * @param {Function} fn
     * @param {Boolean} capture
     * @return {Function}
     * @api public
     */
    
    exports.bind = function(el, selector, type, fn, capture){
      return event.bind(el, type, function(e){
        if (matches(e.target, selector)) fn(e);
      }, capture);
      return callback;
    };
    
    /**
     * Unbind event `type`'s callback `fn`.
     *
     * @param {Element} el
     * @param {String} type
     * @param {Function} fn
     * @param {Boolean} capture
     * @api public
     */
    
    exports.unbind = function(el, type, fn, capture){
      event.unbind(el, type, fn, capture);
    };
    
    });
    require.register("component-domify/index.js", function(exports, require, module){
    
    /**
     * Expose `parse`.
     */
    
    module.exports = parse;
    
    /**
     * Wrap map from jquery.
     */
    
    var map = {
      option: [1, '<select multiple="multiple">', '</select>'],
      optgroup: [1, '<select multiple="multiple">', '</select>'],
      legend: [1, '<fieldset>', '</fieldset>'],
      thead: [1, '<table>', '</table>'],
      tbody: [1, '<table>', '</table>'],
      tfoot: [1, '<table>', '</table>'],
      colgroup: [1, '<table>', '</table>'],
      caption: [1, '<table>', '</table>'],
      tr: [2, '<table><tbody>', '</tbody></table>'],
      td: [3, '<table><tbody><tr>', '</tr></tbody></table>'],
      th: [3, '<table><tbody><tr>', '</tr></tbody></table>'],
      col: [2, '<table><tbody></tbody><colgroup>', '</colgroup></table>'],
      _default: [0, '', '']
    };
    
    /**
     * Parse `html` and return the children.
     *
     * @param {String} html
     * @return {Array}
     * @api private
     */
    
    function parse(html) {
      if ('string' != typeof html) throw new TypeError('String expected');
    
      // tag name
      var m = /<([\w:]+)/.exec(html);
      if (!m) throw new Error('No elements were generated.');
      var tag = m[1];
    
      // body support
      if (tag == 'body') {
        var el = document.createElement('html');
        el.innerHTML = html;
        return el.removeChild(el.lastChild);
      }
    
      // wrap map
      var wrap = map[tag] || map._default;
      var depth = wrap[0];
      var prefix = wrap[1];
      var suffix = wrap[2];
      var el = document.createElement('div');
      el.innerHTML = prefix + html + suffix;
      while (depth--) el = el.lastChild;
    
      var els = el.children;
      if (1 == els.length) {
        return el.removeChild(els[0]);
      }
    
      var fragment = document.createDocumentFragment();
      while (els.length) {
        fragment.appendChild(el.removeChild(els[0]));
      }
    
      return fragment;
    }
    
    });
    require.register("component-indexof/index.js", function(exports, require, module){
    module.exports = function(arr, obj){
      if (arr.indexOf) return arr.indexOf(obj);
      for (var i = 0; i < arr.length; ++i) {
        if (arr[i] === obj) return i;
      }
      return -1;
    };
    });
    require.register("component-classes/index.js", function(exports, require, module){
    
    /**
     * Module dependencies.
     */
    
    var index = require('indexof');
    
    /**
     * Whitespace regexp.
     */
    
    var re = /\s+/;
    
    /**
     * toString reference.
     */
    
    var toString = Object.prototype.toString;
    
    /**
     * Wrap `el` in a `ClassList`.
     *
     * @param {Element} el
     * @return {ClassList}
     * @api public
     */
    
    module.exports = function(el){
      return new ClassList(el);
    };
    
    /**
     * Initialize a new ClassList for `el`.
     *
     * @param {Element} el
     * @api private
     */
    
    function ClassList(el) {
      this.el = el;
      this.list = el.classList;
    }
    
    /**
     * Add class `name` if not already present.
     *
     * @param {String} name
     * @return {ClassList}
     * @api public
     */
    
    ClassList.prototype.add = function(name){
      // classList
      if (this.list) {
        this.list.add(name);
        return this;
      }
    
      // fallback
      var arr = this.array();
      var i = index(arr, name);
      if (!~i) arr.push(name);
      this.el.className = arr.join(' ');
      return this;
    };
    
    /**
     * Remove class `name` when present, or
     * pass a regular expression to remove
     * any which match.
     *
     * @param {String|RegExp} name
     * @return {ClassList}
     * @api public
     */
    
    ClassList.prototype.remove = function(name){
      if ('[object RegExp]' == toString.call(name)) {
        return this.removeMatching(name);
      }
    
      // classList
      if (this.list) {
        this.list.remove(name);
        return this;
      }
    
      // fallback
      var arr = this.array();
      var i = index(arr, name);
      if (~i) arr.splice(i, 1);
      this.el.className = arr.join(' ');
      return this;
    };
    
    /**
     * Remove all classes matching `re`.
     *
     * @param {RegExp} re
     * @return {ClassList}
     * @api private
     */
    
    ClassList.prototype.removeMatching = function(re){
      var arr = this.array();
      for (var i = 0; i < arr.length; i++) {
        if (re.test(arr[i])) {
          this.remove(arr[i]);
        }
      }
      return this;
    };
    
    /**
     * Toggle class `name`.
     *
     * @param {String} name
     * @return {ClassList}
     * @api public
     */
    
    ClassList.prototype.toggle = function(name){
      // classList
      if (this.list) {
        this.list.toggle(name);
        return this;
      }
    
      // fallback
      if (this.has(name)) {
        this.remove(name);
      } else {
        this.add(name);
      }
      return this;
    };
    
    /**
     * Return an array of classes.
     *
     * @return {Array}
     * @api public
     */
    
    ClassList.prototype.array = function(){
      var str = this.el.className.replace(/^\s+|\s+$/g, '');
      var arr = str.split(re);
      if ('' === arr[0]) arr.shift();
      return arr;
    };
    
    /**
     * Check if class `name` is present.
     *
     * @param {String} name
     * @return {ClassList}
     * @api public
     */
    
    ClassList.prototype.has =
    ClassList.prototype.contains = function(name){
      return this.list
        ? this.list.contains(name)
        : !! ~index(this.array(), name);
    };
    
    });
    require.register("visionmedia-debug/index.js", function(exports, require, module){
    if ('undefined' == typeof window) {
      module.exports = require('./lib/debug');
    } else {
      module.exports = require('./debug');
    }
    
    });
    require.register("visionmedia-debug/debug.js", function(exports, require, module){
    
    /**
     * Expose `debug()` as the module.
     */
    
    module.exports = debug;
    
    /**
     * Create a debugger with the given `name`.
     *
     * @param {String} name
     * @return {Type}
     * @api public
     */
    
    function debug(name) {
      if (!debug.enabled(name)) return function(){};
    
      return function(fmt){
        fmt = coerce(fmt);
    
        var curr = new Date;
        var ms = curr - (debug[name] || curr);
        debug[name] = curr;
    
        fmt = name
          + ' '
          + fmt
          + ' +' + debug.humanize(ms);
    
        // This hackery is required for IE8
        // where `console.log` doesn't have 'apply'
        window.console
          && console.log
          && Function.prototype.apply.call(console.log, console, arguments);
      }
    }
    
    /**
     * The currently active debug mode names.
     */
    
    debug.names = [];
    debug.skips = [];
    
    /**
     * Enables a debug mode by name. This can include modes
     * separated by a colon and wildcards.
     *
     * @param {String} name
     * @api public
     */
    
    debug.enable = function(name) {
      try {
        localStorage.debug = name;
      } catch(e){}
    
      var split = (name || '').split(/[\s,]+/)
        , len = split.length;
    
      for (var i = 0; i < len; i++) {
        name = split[i].replace('*', '.*?');
        if (name[0] === '-') {
          debug.skips.push(new RegExp('^' + name.substr(1) + '$'));
        }
        else {
          debug.names.push(new RegExp('^' + name + '$'));
        }
      }
    };
    
    /**
     * Disable debug output.
     *
     * @api public
     */
    
    debug.disable = function(){
      debug.enable('');
    };
    
    /**
     * Humanize the given `ms`.
     *
     * @param {Number} m
     * @return {String}
     * @api private
     */
    
    debug.humanize = function(ms) {
      var sec = 1000
        , min = 60 * 1000
        , hour = 60 * min;
    
      if (ms >= hour) return (ms / hour).toFixed(1) + 'h';
      if (ms >= min) return (ms / min).toFixed(1) + 'm';
      if (ms >= sec) return (ms / sec | 0) + 's';
      return ms + 'ms';
    };
    
    /**
     * Returns true if the given mode name is enabled, false otherwise.
     *
     * @param {String} name
     * @return {Boolean}
     * @api public
     */
    
    debug.enabled = function(name) {
      for (var i = 0, len = debug.skips.length; i < len; i++) {
        if (debug.skips[i].test(name)) {
          return false;
        }
      }
      for (var i = 0, len = debug.names.length; i < len; i++) {
        if (debug.names[i].test(name)) {
          return true;
        }
      }
      return false;
    };
    
    /**
     * Coerce `val`.
     */
    
    function coerce(val) {
      if (val instanceof Error) return val.stack || val.message;
      return val;
    }
    
    // persist
    
    try {
      if (window.localStorage) debug.enable(localStorage.debug);
    } catch(e){}
    
    });
    require.register("ianstormtaylor-to-no-case/index.js", function(exports, require, module){
    
    /**
     * Expose `toNoCase`.
     */
    
    module.exports = toNoCase;
    
    
    /**
     * Test whether a string is camel-case.
     */
    
    var hasSpace = /\s/;
    var hasCamel = /[a-z][A-Z]/;
    var hasSeparator = /[\W_]/;
    
    
    /**
     * Remove any starting case from a `string`, like camel or snake, but keep
     * spaces and punctuation that may be important otherwise.
     *
     * @param {String} string
     * @return {String}
     */
    
    function toNoCase (string) {
      if (hasSpace.test(string)) return string.toLowerCase();
    
      if (hasSeparator.test(string)) string = unseparate(string);
      if (hasCamel.test(string)) string = uncamelize(string);
      return string.toLowerCase();
    }
    
    
    /**
     * Separator splitter.
     */
    
    var separatorSplitter = /[\W_]+(.|$)/g;
    
    
    /**
     * Un-separate a `string`.
     *
     * @param {String} string
     * @return {String}
     */
    
    function unseparate (string) {
      return string.replace(separatorSplitter, function (m, next) {
        return next ? ' ' + next : '';
      });
    }
    
    
    /**
     * Camelcase splitter.
     */
    
    var camelSplitter = /(.)([A-Z]+)/g;
    
    
    /**
     * Un-camelcase a `string`.
     *
     * @param {String} string
     * @return {String}
     */
    
    function uncamelize (string) {
      return string.replace(camelSplitter, function (m, previous, uppers) {
        return previous + ' ' + uppers.toLowerCase().split('').join(' ');
      });
    }
    });
    require.register("ianstormtaylor-to-space-case/index.js", function(exports, require, module){
    
    var clean = require('to-no-case');
    
    
    /**
     * Expose `toSpaceCase`.
     */
    
    module.exports = toSpaceCase;
    
    
    /**
     * Convert a `string` to space case.
     *
     * @param {String} string
     * @return {String}
     */
    
    
    function toSpaceCase (string) {
      return clean(string).replace(/[\W_]+(.|$)/g, function (matches, match) {
        return match ? ' ' + match : '';
      });
    }
    });
    require.register("ianstormtaylor-to-camel-case/index.js", function(exports, require, module){
    
    var toSpace = require('to-space-case');
    
    
    /**
     * Expose `toCamelCase`.
     */
    
    module.exports = toCamelCase;
    
    
    /**
     * Convert a `string` to camel case.
     *
     * @param {String} string
     * @return {String}
     */
    
    
    function toCamelCase (string) {
      return toSpace(string).replace(/\s(\w)/g, function (matches, letter) {
        return letter.toUpperCase();
      });
    }
    });
    require.register("component-within-document/index.js", function(exports, require, module){
    
    /**
     * Check if `el` is within the document.
     *
     * @param {Element} el
     * @return {Boolean}
     * @api private
     */
    
    module.exports = function(el) {
      var node = el;
      while (node = node.parentNode) {
        if (node == document) return true;
      }
      return false;
    };
    });
    require.register("component-css/index.js", function(exports, require, module){
    /**
     * Module Dependencies
     */
    
    var debug = require('debug')('css');
    var set = require('./lib/style');
    var get = require('./lib/css');
    
    /**
     * Expose `css`
     */
    
    module.exports = css;
    
    /**
     * Get and set css values
     *
     * @param {Element} el
     * @param {String|Object} prop
     * @param {Mixed} val
     * @return {Element} el
     * @api public
     */
    
    function css(el, prop, val) {
      if (!el) return;
    
      if (undefined !== val) {
        var obj = {};
        obj[prop] = val;
        debug('setting styles %j', obj);
        return setStyles(el, obj);
      }
    
      if ('object' == typeof prop) {
        debug('setting styles %j', prop);
        return setStyles(el, prop);
      }
    
      debug('getting %s', prop);
      return get(el, prop);
    }
    
    /**
     * Set the styles on an element
     *
     * @param {Element} el
     * @param {Object} props
     * @return {Element} el
     */
    
    function setStyles(el, props) {
      for (var prop in props) {
        set(el, prop, props[prop]);
      }
    
      return el;
    }
    
    });
    require.register("component-css/lib/css.js", function(exports, require, module){
    /**
     * Module Dependencies
     */
    
    var debug = require('debug')('css:css');
    var camelcase = require('to-camel-case');
    var computed = require('./computed');
    var property = require('./prop');
    
    /**
     * Expose `css`
     */
    
    module.exports = css;
    
    /**
     * CSS Normal Transforms
     */
    
    var cssNormalTransform = {
      letterSpacing: 0,
      fontWeight: 400
    };
    
    /**
     * Get a CSS value
     *
     * @param {Element} el
     * @param {String} prop
     * @param {Mixed} extra
     * @param {Array} styles
     * @return {String}
     */
    
    function css(el, prop, extra, styles) {
      var hooks = require('./hooks');
      var orig = camelcase(prop);
      var style = el.style;
      var val;
    
      prop = property(prop, style);
      var hook = hooks[prop] || hooks[orig];
    
      // If a hook was provided get the computed value from there
      if (hook && hook.get) {
        debug('get hook provided. use that');
        val = hook.get(el, true, extra);
      }
    
      // Otherwise, if a way to get the computed value exists, use that
      if (undefined == val) {
        debug('fetch the computed value of %s', prop);
        val = computed(el, prop);
      }
    
      if ('normal' == val && cssNormalTransform[prop]) {
        val = cssNormalTransform[prop];
        debug('normal => %s', val);
      }
    
      // Return, converting to number if forced or a qualifier was provided and val looks numeric
      if ('' == extra || extra) {
        debug('converting value: %s into a number');
        var num = parseFloat(val);
        return true === extra || isNumeric(num) ? num || 0 : val;
      }
    
      return val;
    }
    
    /**
     * Is Numeric
     *
     * @param {Mixed} obj
     * @return {Boolean}
     */
    
    function isNumeric(obj) {
      return !isNan(parseFloat(obj)) && isFinite(obj);
    }
    
    });
    require.register("component-css/lib/prop.js", function(exports, require, module){
    /**
     * Module dependencies
     */
    
    var debug = require('debug')('css:prop');
    var camelcase = require('to-camel-case');
    var vendor = require('./vendor');
    
    /**
     * Export `prop`
     */
    
    module.exports = prop;
    
    /**
     * Normalize Properties
     */
    
    var cssProps = {
      'float': 'cssFloat'
    };
    
    /**
     * Get the vendor prefixed property
     *
     * @param {String} prop
     * @param {String} style
     * @return {String} prop
     * @api private
     */
    
    function prop(prop, style) {
      prop = cssProps[prop] || (cssProps[prop] = vendor(prop, style));
      debug('transform property: %s => %s');
      return prop;
    }
    
    });
    require.register("component-css/lib/swap.js", function(exports, require, module){
    /**
     * Export `swap`
     */
    
    module.exports = swap;
    
    /**
     * Initialize `swap`
     *
     * @param {Element} el
     * @param {Object} options
     * @param {Function} fn
     * @param {Array} args
     * @return {Mixed}
     */
    
    function swap(el, options, fn, args) {
      // Remember the old values, and insert the new ones
      for (var key in options) {
        old[key] = el.style[key];
        el.style[key] = options[key];
      }
    
      ret = fn.apply(el, args || []);
    
      // Revert the old values
      for (key in options) {
        el.style[key] = old[key];
      }
    
      return ret;
    }
    
    });
    require.register("component-css/lib/style.js", function(exports, require, module){
    /**
     * Module Dependencies
     */
    
    var debug = require('debug')('css:style');
    var camelcase = require('to-camel-case');
    var support = require('./support');
    var property = require('./prop');
    var hooks = require('./hooks');
    
    /**
     * Expose `style`
     */
    
    module.exports = style;
    
    /**
     * Possibly-unitless properties
     *
     * Don't automatically add 'px' to these properties
     */
    
    var cssNumber = {
      "columnCount": true,
      "fillOpacity": true,
      "fontWeight": true,
      "lineHeight": true,
      "opacity": true,
      "order": true,
      "orphans": true,
      "widows": true,
      "zIndex": true,
      "zoom": true
    };
    
    /**
     * Set a css value
     *
     * @param {Element} el
     * @param {String} prop
     * @param {Mixed} val
     * @param {Mixed} extra
     */
    
    function style(el, prop, val, extra) {
      // Don't set styles on text and comment nodes
      if (!el || el.nodeType === 3 || el.nodeType === 8 || !el.style ) return;
    
      var orig = camelcase(prop);
      var style = el.style;
      var type = typeof val;
    
      if (!val) return get(el, prop, orig, extra);
    
      prop = property(prop, style);
    
      var hook = hooks[prop] || hooks[orig];
    
      // If a number was passed in, add 'px' to the (except for certain CSS properties)
      if ('number' == type && !cssNumber[orig]) {
        debug('adding "px" to end of number');
        val += 'px';
      }
    
      // Fixes jQuery #8908, it can be done more correctly by specifying setters in cssHooks,
      // but it would mean to define eight (for every problematic property) identical functions
      if (!support.clearCloneStyle && '' === val && 0 === prop.indexOf('background')) {
        debug('set property (%s) value to "inherit"', prop);
        style[prop] = 'inherit';
      }
    
      // If a hook was provided, use that value, otherwise just set the specified value
      if (!hook || !hook.set || undefined !== (val = hook.set(el, val, extra))) {
        // Support: Chrome, Safari
        // Setting style to blank string required to delete "style: x !important;"
        debug('set hook defined. setting property (%s) to %s', prop, val);
        style[prop] = '';
        style[prop] = val;
      }
    
    }
    
    /**
     * Get the style
     *
     * @param {Element} el
     * @param {String} prop
     * @param {String} orig
     * @param {Mixed} extra
     * @return {String}
     */
    
    function get(el, prop, orig, extra) {
      var style = el.style;
      var hook = hooks[prop] || hooks[orig];
      var ret;
    
      if (hook && hook.get && undefined !== (ret = hook.get(el, false, extra))) {
        debug('get hook defined, returning: %s', ret);
        return ret;
      }
    
      ret = style[prop];
      debug('getting %s', ret);
      return ret;
    }
    
    });
    require.register("component-css/lib/hooks.js", function(exports, require, module){
    /**
     * Module Dependencies
     */
    
    var css = require('./css');
    var cssShow = { position: 'absolute', visibility: 'hidden', display: 'block' };
    var pnum = (/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/).source;
    var rnumnonpx = new RegExp( '^(' + pnum + ')(?!px)[a-z%]+$', 'i');
    var rnumsplit = new RegExp( '^(' + pnum + ')(.*)$', 'i');
    var rdisplayswap = /^(none|table(?!-c[ea]).+)/;
    var styles = require('./styles');
    var support = require('./support');
    var swap = require('./swap');
    var computed = require('./computed');
    var cssExpand = [ "Top", "Right", "Bottom", "Left" ];
    
    /**
     * Height & Width
     */
    
    ['width', 'height'].forEach(function(name) {
      exports[name] = {};
    
      exports[name].get = function(el, compute, extra) {
        if (!compute) return;
        // certain elements can have dimension info if we invisibly show them
        // however, it must have a current display style that would benefit from this
        return 0 == el.offsetWidth && rdisplayswap.test(css(el, 'display'))
          ? swap(el, cssShow, function() { return getWidthOrHeight(el, name, extra); })
          : getWidthOrHeight(el, name, extra);
      }
    
      exports[name].set = function(el, val, extra) {
        var styles = extra && styles(el);
        return setPositiveNumber(el, val, extra
          ? augmentWidthOrHeight(el, name, extra, 'border-box' == css(el, 'boxSizing', false, styles), styles)
          : 0
        );
      };
    
    });
    
    /**
     * Opacity
     */
    
    exports.opacity = {};
    exports.opacity.get = function(el, compute) {
      if (!compute) return;
      var ret = computed(el, 'opacity');
      return '' == ret ? '1' : ret;
    }
    
    /**
     * Utility: Set Positive Number
     *
     * @param {Element} el
     * @param {Mixed} val
     * @param {Number} subtract
     * @return {Number}
     */
    
    function setPositiveNumber(el, val, subtract) {
      var matches = rnumsplit.exec(val);
      return matches ?
        // Guard against undefined 'subtract', e.g., when used as in cssHooks
        Math.max(0, matches[1]) + (matches[2] || 'px') :
        val;
    }
    
    /**
     * Utility: Get the width or height
     *
     * @param {Element} el
     * @param {String} prop
     * @param {Mixed} extra
     * @return {String}
     */
    
    function getWidthOrHeight(el, prop, extra) {
      // Start with offset property, which is equivalent to the border-box value
      var valueIsBorderBox = true;
      var val = prop === 'width' ? el.offsetWidth : el.offsetHeight;
      var styles = computed(el);
      var isBorderBox = support.boxSizing && css(el, 'boxSizing') === 'border-box';
    
      // some non-html elements return undefined for offsetWidth, so check for null/undefined
      // svg - https://bugzilla.mozilla.org/show_bug.cgi?id=649285
      // MathML - https://bugzilla.mozilla.org/show_bug.cgi?id=491668
      if (val <= 0 || val == null) {
        // Fall back to computed then uncomputed css if necessary
        val = computed(el, prop, styles);
    
        if (val < 0 || val == null) {
          val = el.style[prop];
        }
    
        // Computed unit is not pixels. Stop here and return.
        if (rnumnonpx.test(val)) {
          return val;
        }
    
        // we need the check for style in case a browser which returns unreliable values
        // for getComputedStyle silently falls back to the reliable el.style
        valueIsBorderBox = isBorderBox && (support.boxSizingReliable() || val === el.style[prop]);
    
        // Normalize ', auto, and prepare for extra
        val = parseFloat(val) || 0;
      }
    
      // use the active box-sizing model to add/subtract irrelevant styles
      extra = extra || (isBorderBox ? 'border' : 'content');
      val += augmentWidthOrHeight(el, prop, extra, valueIsBorderBox, styles);
      return val + 'px';
    }
    
    /**
     * Utility: Augment the width or the height
     *
     * @param {Element} el
     * @param {String} prop
     * @param {Mixed} extra
     * @param {Boolean} isBorderBox
     * @param {Array} styles
     */
    
    function augmentWidthOrHeight(el, prop, extra, isBorderBox, styles) {
      // If we already have the right measurement, avoid augmentation,
      // Otherwise initialize for horizontal or vertical properties
      var i = extra === (isBorderBox ? 'border' : 'content') ? 4 : 'width' == prop ? 1 : 0;
      var val = 0;
    
      for (; i < 4; i += 2) {
        // both box models exclude margin, so add it if we want it
        if (extra === 'margin') {
          val += css(el, extra + cssExpand[i], true, styles);
        }
    
        if (isBorderBox) {
          // border-box includes padding, so remove it if we want content
          if (extra === 'content') {
            val -= css(el, 'padding' + cssExpand[i], true, styles);
          }
    
          // at this point, extra isn't border nor margin, so remove border
          if (extra !== 'margin') {
            val -= css(el, 'border' + cssExpand[i] + 'Width', true, styles);
          }
        } else {
          // at this point, extra isn't content, so add padding
          val += css(el, 'padding' + cssExpand[i], true, styles);
    
          // at this point, extra isn't content nor padding, so add border
          if (extra !== 'padding') {
            val += css(el, 'border' + cssExpand[i] + 'Width', true, styles);
          }
        }
      }
    
      return val;
    }
    
    });
    require.register("component-css/lib/styles.js", function(exports, require, module){
    /**
     * Expose `styles`
     */
    
    module.exports = styles;
    
    /**
     * Get all the styles
     *
     * @param {Element} el
     * @return {Array}
     */
    
    function styles(el) {
      return el.ownerDocument.defaultView.getComputedStyle(el, null);
    }
    
    });
    require.register("component-css/lib/vendor.js", function(exports, require, module){
    /**
     * Module Dependencies
     */
    
    var prefixes = ['Webkit', 'O', 'Moz', 'ms'];
    
    /**
     * Expose `vendor`
     */
    
    module.exports = vendor;
    
    /**
     * Get the vendor prefix for a given property
     *
     * @param {String} prop
     * @param {Object} style
     * @return {String}
     */
    
    function vendor(prop, style) {
      // shortcut for names that are not vendor prefixed
      if (style[prop]) return prop;
    
      // check for vendor prefixed names
      var capName = prop[0].toUpperCase() + prop.slice(1);
      var original = prop;
      var i = prefixes.length;
    
      while (i--) {
        prop = prefixes[i] + capName;
        if (prop in style) return prop;
      }
    
      return original;
    }
    
    });
    require.register("component-css/lib/support.js", function(exports, require, module){
    /**
     * Support values
     */
    
    var reliableMarginRight;
    var boxSizingReliableVal;
    var pixelPositionVal;
    var clearCloneStyle;
    
    /**
     * Container setup
     */
    
    var docElem = document.documentElement;
    var container = document.createElement('div');
    var div = document.createElement('div');
    
    /**
     * Clear clone style
     */
    
    div.style.backgroundClip = 'content-box';
    div.cloneNode(true).style.backgroundClip = '';
    exports.clearCloneStyle = div.style.backgroundClip === 'content-box';
    
    container.style.cssText = 'border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px';
    container.appendChild(div);
    
    /**
     * Pixel position
     *
     * Webkit bug: https://bugs.webkit.org/show_bug.cgi?id=29084
     * getComputedStyle returns percent when specified for top/left/bottom/right
     * rather than make the css module depend on the offset module, we just check for it here
     */
    
    exports.pixelPosition = function() {
      if (undefined == pixelPositionVal) computePixelPositionAndBoxSizingReliable();
      return pixelPositionVal;
    }
    
    /**
     * Reliable box sizing
     */
    
    exports.boxSizingReliable = function() {
      if (undefined == boxSizingReliableVal) computePixelPositionAndBoxSizingReliable();
      return boxSizingReliableVal;
    }
    
    /**
     * Reliable margin right
     *
     * Support: Android 2.3
     * Check if div with explicit width and no margin-right incorrectly
     * gets computed margin-right based on width of container. (#3333)
     * WebKit Bug 13343 - getComputedStyle returns wrong value for margin-right
     * This support function is only executed once so no memoizing is needed.
     *
     * @return {Boolean}
     */
    
    exports.reliableMarginRight = function() {
      var ret;
      var marginDiv = div.appendChild(document.createElement("div" ));
    
      marginDiv.style.cssText = div.style.cssText = divReset;
      marginDiv.style.marginRight = marginDiv.style.width = "0";
      div.style.width = "1px";
      docElem.appendChild(container);
    
      ret = !parseFloat(window.getComputedStyle(marginDiv, null).marginRight);
    
      docElem.removeChild(container);
    
      // Clean up the div for other support tests.
      div.innerHTML = "";
    
      return ret;
    }
    
    /**
     * Executing both pixelPosition & boxSizingReliable tests require only one layout
     * so they're executed at the same time to save the second computation.
     */
    
    function computePixelPositionAndBoxSizingReliable() {
      // Support: Firefox, Android 2.3 (Prefixed box-sizing versions).
      div.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;" +
        "box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;" +
        "position:absolute;top:1%";
      docElem.appendChild(container);
    
      var divStyle = window.getComputedStyle(div, null);
      pixelPositionVal = divStyle.top !== "1%";
      boxSizingReliableVal = divStyle.width === "4px";
    
      docElem.removeChild(container);
    }
    
    
    
    });
    require.register("component-css/lib/computed.js", function(exports, require, module){
    /**
     * Module Dependencies
     */
    
    var debug = require('debug')('css:computed');
    var withinDocument = require('within-document');
    var styles = require('./styles');
    
    /**
     * Expose `computed`
     */
    
    module.exports = computed;
    
    /**
     * Get the computed style
     *
     * @param {Element} el
     * @param {String} prop
     * @param {Array} precomputed (optional)
     * @return {Array}
     * @api private
     */
    
    function computed(el, prop, precomputed) {
      computed = precomputed || styles(el);
      if (!computed) return;
    
      var ret = computed.getPropertyValue(prop) || computed[prop];
    
      if ('' === ret && !withinDocument(el)) {
        debug('element not within document, try finding from style attribute');
        var style = require('./style');
        ret = style(el, prop);
      }
    
      debug('computed value of %s: %s', prop, ret);
    
      // Support: IE
      // IE returns zIndex value as an integer.
      return undefined === ret ? ret : ret + '';
    }
    
    });
    require.register("component-type/index.js", function(exports, require, module){
    /**
     * toString ref.
     */
    
    var toString = Object.prototype.toString;
    
    /**
     * Return the type of `val`.
     *
     * @param {Mixed} val
     * @return {String}
     * @api public
     */
    
    module.exports = function(val){
      switch (toString.call(val)) {
        case '[object Date]': return 'date';
        case '[object RegExp]': return 'regexp';
        case '[object Arguments]': return 'arguments';
        case '[object Array]': return 'array';
      }
    
      if (val === null) return 'null';
      if (val === undefined) return 'undefined';
      if (val && val.nodeType === 1) return 'element';
    
      return typeof val.valueOf();
    };
    
    });
    require.register("component-value/index.js", function(exports, require, module){
    
    /**
     * Module dependencies.
     */
    
    var typeOf = require('type');
    
    /**
     * Set or get `el`'s' value.
     *
     * @param {Element} el
     * @param {Mixed} val
     * @return {Mixed}
     * @api public
     */
    
    module.exports = function(el, val){
      if (2 == arguments.length) return set(el, val);
      return get(el);
    };
    
    /**
     * Get `el`'s value.
     */
    
    function get(el) {
      switch (type(el)) {
        case 'checkbox':
        case 'radio':
          if (el.checked) {
            var attr = el.getAttribute('value');
            return null == attr ? true : attr;
          } else {
            return false;
          }
        case 'radiogroup':
          for (var i = 0, radio; radio = el[i]; i++) {
            if (radio.checked) return radio.value;
          }
          break;
        case 'select':
          for (var i = 0, option; option = el.options[i]; i++) {
            if (option.selected) return option.value;
          }
          break;
        default:
          return el.value;
      }
    }
    
    /**
     * Set `el`'s value.
     */
    
    function set(el, val) {
      switch (type(el)) {
        case 'checkbox':
        case 'radio':
          if (val) {
            el.checked = true;
          } else {
            el.checked = false;
          }
          break;
        case 'radiogroup':
          for (var i = 0, radio; radio = el[i]; i++) {
            radio.checked = radio.value === val;
          }
          break;
        case 'select':
          for (var i = 0, option; option = el.options[i]; i++) {
            option.selected = option.value === val;
          }
          break;
        default:
          el.value = val;
      }
    }
    
    /**
     * Element type.
     */
    
    function type(el) {
      var group = 'array' == typeOf(el) || 'object' == typeOf(el);
      if (group) el = el[0];
      var name = el.nodeName.toLowerCase();
      var type = el.getAttribute('type');
    
      if (group && type && 'radio' == type.toLowerCase()) return 'radiogroup';
      if ('input' == name && type && 'checkbox' == type.toLowerCase()) return 'checkbox';
      if ('input' == name && type && 'radio' == type.toLowerCase()) return 'radio';
      if ('select' == name) return 'select';
      return name;
    }
    
    });
    require.register("component-query/index.js", function(exports, require, module){
    function one(selector, el) {
      return el.querySelector(selector);
    }
    
    exports = module.exports = function(selector, el){
      el = el || document;
      return one(selector, el);
    };
    
    exports.all = function(selector, el){
      el = el || document;
      return el.querySelectorAll(selector);
    };
    
    exports.engine = function(obj){
      if (!obj.one) throw new Error('.one callback required');
      if (!obj.all) throw new Error('.all callback required');
      one = obj.one;
      exports.all = obj.all;
      return exports;
    };
    
    });
    require.register("component-matches-selector/index.js", function(exports, require, module){
    /**
     * Module dependencies.
     */
    
    var query = require('query');
    
    /**
     * Element prototype.
     */
    
    var proto = Element.prototype;
    
    /**
     * Vendor function.
     */
    
    var vendor = proto.matches
      || proto.webkitMatchesSelector
      || proto.mozMatchesSelector
      || proto.msMatchesSelector
      || proto.oMatchesSelector;
    
    /**
     * Expose `match()`.
     */
    
    module.exports = match;
    
    /**
     * Match `el` to `selector`.
     *
     * @param {Element} el
     * @param {String} selector
     * @return {Boolean}
     * @api public
     */
    
    function match(el, selector) {
      if (vendor) return vendor.call(el, selector);
      var nodes = query.all(selector, el.parentNode);
      for (var i = 0; i < nodes.length; ++i) {
        if (nodes[i] == el) return true;
      }
      return false;
    }
    
    });
    require.register("yields-traverse/index.js", function(exports, require, module){
    
    /**
     * dependencies
     */
    
    var matches = require('matches-selector');
    
    /**
     * Traverse with the given `el`, `selector` and `len`.
     *
     * @param {String} type
     * @param {Element} el
     * @param {String} selector
     * @param {Number} len
     * @return {Array}
     * @api public
     */
    
    module.exports = function(type, el, selector, len){
      var el = el[type]
        , n = len || 1
        , ret = [];
    
      if (!el) return ret;
    
      do {
        if (n == ret.length) break;
        if (1 != el.nodeType) continue;
        if (matches(el, selector)) ret.push(el);
        if (!selector) ret.push(el);
      } while (el = el[type]);
    
      return ret;
    }
    
    });
    require.register("component-trim/index.js", function(exports, require, module){
    
    exports = module.exports = trim;
    
    function trim(str){
      if (str.trim) return str.trim();
      return str.replace(/^\s*|\s*$/g, '');
    }
    
    exports.left = function(str){
      if (str.trimLeft) return str.trimLeft();
      return str.replace(/^\s*/, '');
    };
    
    exports.right = function(str){
      if (str.trimRight) return str.trimRight();
      return str.replace(/\s*$/, '');
    };
    
    });
    require.register("yields-isArray/index.js", function(exports, require, module){
    
    /**
     * isArray
     */
    
    var isArray = Array.isArray;
    
    /**
     * toString
     */
    
    var str = Object.prototype.toString;
    
    /**
     * Wether or not the given `val`
     * is an array.
     *
     * example:
     *
     *        isArray([]);
     *        // > true
     *        isArray(arguments);
     *        // > false
     *        isArray('');
     *        // > false
     *
     * @param {mixed} val
     * @return {bool}
     */
    
    module.exports = isArray || function (val) {
      return !! val && '[object Array]' == str.call(val);
    };
    
    });
    require.register("component-props/index.js", function(exports, require, module){
    /**
     * Global Names
     */
    
    var globals = /\b(Array|Date|Object|Math|JSON)\b/g;
    
    /**
     * Return immediate identifiers parsed from `str`.
     *
     * @param {String} str
     * @param {String|Function} map function or prefix
     * @return {Array}
     * @api public
     */
    
    module.exports = function(str, fn){
      var p = unique(props(str));
      if (fn && 'string' == typeof fn) fn = prefixed(fn);
      if (fn) return map(str, p, fn);
      return p;
    };
    
    /**
     * Return immediate identifiers in `str`.
     *
     * @param {String} str
     * @return {Array}
     * @api private
     */
    
    function props(str) {
      return str
        .replace(/\.\w+|\w+ *\(|"[^"]*"|'[^']*'|\/([^/]+)\//g, '')
        .replace(globals, '')
        .match(/[a-zA-Z_]\w*/g)
        || [];
    }
    
    /**
     * Return `str` with `props` mapped with `fn`.
     *
     * @param {String} str
     * @param {Array} props
     * @param {Function} fn
     * @return {String}
     * @api private
     */
    
    function map(str, props, fn) {
      var re = /\.\w+|\w+ *\(|"[^"]*"|'[^']*'|\/([^/]+)\/|[a-zA-Z_]\w*/g;
      return str.replace(re, function(_){
        if ('(' == _[_.length - 1]) return fn(_);
        if (!~props.indexOf(_)) return _;
        return fn(_);
      });
    }
    
    /**
     * Return unique array.
     *
     * @param {Array} arr
     * @return {Array}
     * @api private
     */
    
    function unique(arr) {
      var ret = [];
    
      for (var i = 0; i < arr.length; i++) {
        if (~ret.indexOf(arr[i])) continue;
        ret.push(arr[i]);
      }
    
      return ret;
    }
    
    /**
     * Map with prefix `str`.
     */
    
    function prefixed(str) {
      return function(_){
        return str + _;
      };
    }
    
    });
    require.register("component-to-function/index.js", function(exports, require, module){
    /**
     * Module Dependencies
     */
    
    try {
      var expr = require('props');
    } catch(e) {
      var expr = require('props-component');
    }
    
    /**
     * Expose `toFunction()`.
     */
    
    module.exports = toFunction;
    
    /**
     * Convert `obj` to a `Function`.
     *
     * @param {Mixed} obj
     * @return {Function}
     * @api private
     */
    
    function toFunction(obj) {
      switch ({}.toString.call(obj)) {
        case '[object Object]':
          return objectToFunction(obj);
        case '[object Function]':
          return obj;
        case '[object String]':
          return stringToFunction(obj);
        case '[object RegExp]':
          return regexpToFunction(obj);
        default:
          return defaultToFunction(obj);
      }
    }
    
    /**
     * Default to strict equality.
     *
     * @param {Mixed} val
     * @return {Function}
     * @api private
     */
    
    function defaultToFunction(val) {
      return function(obj){
        return val === obj;
      }
    }
    
    /**
     * Convert `re` to a function.
     *
     * @param {RegExp} re
     * @return {Function}
     * @api private
     */
    
    function regexpToFunction(re) {
      return function(obj){
        return re.test(obj);
      }
    }
    
    /**
     * Convert property `str` to a function.
     *
     * @param {String} str
     * @return {Function}
     * @api private
     */
    
    function stringToFunction(str) {
      // immediate such as "> 20"
      if (/^ *\W+/.test(str)) return new Function('_', 'return _ ' + str);
    
      // properties such as "name.first" or "age > 18" or "age > 18 && age < 36"
      return new Function('_', 'return ' + get(str));
    }
    
    /**
     * Convert `object` to a function.
     *
     * @param {Object} object
     * @return {Function}
     * @api private
     */
    
    function objectToFunction(obj) {
      var match = {}
      for (var key in obj) {
        match[key] = typeof obj[key] === 'string'
          ? defaultToFunction(obj[key])
          : toFunction(obj[key])
      }
      return function(val){
        if (typeof val !== 'object') return false;
        for (var key in match) {
          if (!(key in val)) return false;
          if (!match[key](val[key])) return false;
        }
        return true;
      }
    }
    
    /**
     * Built the getter function. Supports getter style functions
     *
     * @param {String} str
     * @return {String}
     * @api private
     */
    
    function get(str) {
      var props = expr(str);
      if (!props.length) return '_.' + str;
    
      var val;
      for(var i = 0, prop; prop = props[i]; i++) {
        val = '_.' + prop;
        val = "('function' == typeof " + val + " ? " + val + "() : " + val + ")";
        str = str.replace(new RegExp(prop, 'g'), val);
      }
    
      return str;
    }
    
    });
    require.register("dom/index.js", function(exports, require, module){
    /**
     * Module dependencies.
     */
    
    var isArray = require('isArray');
    var domify = require('domify');
    var events = require('event');
    var query = require('query');
    var trim = require('trim');
    var slice = [].slice;
    
    /**
     * Attributes supported.
     */
    
    var attrs = [
      'id',
      'src',
      'rel',
      'cols',
      'rows',
      'type',
      'name',
      'href',
      'title',
      'style',
      'width',
      'height',
      'action',
      'method',
      'tabindex',
      'placeholder'
    ];
    
    /*
     * A simple way to check for HTML strings or ID strings
     */
    
    var quickExpr = /^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/;
    
    /**
     * Expose `dom()`.
     */
    
    module.exports = dom;
    
    /**
     * Return a dom `List` for the given
     * `html`, selector, or element.
     *
     * @param {String|Element|List} selector
     * @param {String|ELement|context} context
     * @return {List}
     * @api public
     */
    
    function dom(selector, context) {
      // array
      if (isArray(selector)) {
        return new List(selector);
      }
    
      // List
      if (selector instanceof List) {
        return selector;
      }
    
      // node
      if (selector.nodeName) {
        return new List([selector]);
      }
    
      if ('string' != typeof selector) {
        throw new TypeError('invalid selector');
      }
    
      // html
      var htmlselector = trim.left(selector);
      if (isHTML(htmlselector)) {
        return new List([domify(htmlselector)], htmlselector);
      }
    
      // selector
      var ctx = context
        ? (context instanceof List ? context[0] : context)
        : document;
    
      return new List(query.all(selector, ctx), selector);
    }
    
    /**
     * Static: Expose `List`
     */
    
    dom.List = List;
    
    /**
     * Static: Expose supported attrs.
     */
    
    dom.attrs = attrs;
    
    /**
     * Static: Mixin a function
     *
     * @param {Object|String} name
     * @param {Object|Function} obj
     * @return {List} self
     */
    
    dom.use = function(name, fn) {
      var keys = [];
      var tmp;
    
      if (2 == arguments.length) {
        keys.push(name);
        tmp = {};
        tmp[name] = fn;
        fn = tmp;
      } else if (name.name) {
        // use function name
        fn = name;
        name = name.name;
        keys.push(name);
        tmp = {};
        tmp[name] = fn;
        fn = tmp;
      } else {
        keys = Object.keys(name);
        fn = name;
      }
    
      for(var i = 0, len = keys.length; i < len; i++) {
        List.prototype[keys[i]] = fn[keys[i]];
      }
    
      return this;
    }
    
    /**
     * Initialize a new `List` with the
     * given array-ish of `els` and `selector`
     * string.
     *
     * @param {Mixed} els
     * @param {String} selector
     * @api private
     */
    
    function List(els, selector) {
      els = els || [];
      var len = this.length = els.length;
      for(var i = 0; i < len; i++) this[i] = els[i];
      this.selector = selector;
    }
    
    /**
     * Remake the list
     *
     * @param {String|ELement|context} context
     * @return {List}
     * @api private
     */
    
    List.prototype.dom = dom;
    
    /**
     * Make `List` an array-like object
     */
    
    List.prototype.length = 0;
    List.prototype.splice = Array.prototype.splice;
    
    /**
     * Array-like object to array
     *
     * @return {Array}
     */
    
    List.prototype.toArray = function() {
      return slice.call(this);
    }
    
    /**
     * Attribute accessors.
     */
    
    attrs.forEach(function(name){
      List.prototype[name] = function(val){
        if (0 == arguments.length) return this.attr(name);
        return this.attr(name, val);
      };
    });
    
    /**
     * Mixin the API
     */
    
    dom.use(require('./lib/attributes'));
    dom.use(require('./lib/classes'));
    dom.use(require('./lib/events'));
    dom.use(require('./lib/manipulate'));
    dom.use(require('./lib/traverse'));
    
    /**
     * Check if the string is HTML
     *
     * @param {String} str
     * @return {Boolean}
     * @api private
     */
    
    function isHTML(str) {
      // Faster than running regex, if str starts with `<` and ends with `>`, assume it's HTML
      if (str.charAt(0) === '<' && str.charAt(str.length - 1) === '>' && str.length >= 3) return true;
    
      // Run the regex
      var match = quickExpr.exec(str);
      return !!(match && match[1]);
    }
    
    });
    require.register("dom/lib/traverse.js", function(exports, require, module){
    /**
     * Module Dependencies
     */
    
    var proto = Array.prototype;
    var traverse = require('traverse');
    var toFunction = require('to-function');
    var matches = require('matches-selector');
    
    /**
     * Find children matching the given `selector`.
     *
     * @param {String} selector
     * @return {List}
     * @api public
     */
    
    exports.find = function(selector){
      return this.dom(selector, this);
    };
    
    /**
     * Check if the any element in the selection
     * matches `selector`.
     *
     * @param {String} selector
     * @return {Boolean}
     * @api public
     */
    
    exports.is = function(selector){
      for(var i = 0, el; el = this[i]; i++) {
        if (matches(el, selector)) return true;
      }
    
      return false;
    };
    
    /**
     * Get parent(s) with optional `selector` and `limit`
     *
     * @param {String} selector
     * @param {Number} limit
     * @return {List}
     * @api public
     */
    
    exports.parent = function(selector, limit){
      return this.dom(traverse('parentNode',
        this[0],
        selector,
        limit
        || 1));
    };
    
    /**
     * Get next element(s) with optional `selector` and `limit`.
     *
     * @param {String} selector
     * @param {Number} limit
     * @retrun {List}
     * @api public
     */
    
    exports.next = function(selector, limit){
      return this.dom(traverse('nextSibling',
        this[0],
        selector,
        limit
        || 1));
    };
    
    /**
     * Get previous element(s) with optional `selector` and `limit`.
     *
     * @param {String} selector
     * @param {Number} limit
     * @return {List}
     * @api public
     */
    
    exports.prev =
    exports.previous = function(selector, limit){
      return this.dom(traverse('previousSibling',
        this[0],
        selector,
        limit
        || 1));
    };
    
    /**
     * Iterate over each element creating a new list with
     * one item and invoking `fn(list, i)`.
     *
     * @param {Function} fn
     * @return {List} self
     * @api public
     */
    
    exports.each = function(fn){
      var dom = this.dom;
    
      for (var i = 0, list, len = this.length; i < len; i++) {
        list = dom(this[i]);
        fn.call(list, list, i);
      }
    
      return this;
    };
    
    /**
     * Iterate over each element and invoke `fn(el, i)`
     *
     * @param {Function} fn
     * @return {List} self
     * @api public
     */
    
    exports.forEach = function(fn) {
      for (var i = 0, len = this.length; i < len; i++) {
        fn.call(this[i], this[i], i);
      }
    
      return this;
    };
    
    /**
     * Map each return value from `fn(val, i)`.
     *
     * Passing a callback function:
     *
     *    inputs.map(function(input){
     *      return input.type
     *    })
     *
     * Passing a property string:
     *
     *    inputs.map('type')
     *
     * @param {Function} fn
     * @return {List} self
     * @api public
     */
    
    exports.map = function(fn){
      fn = toFunction(fn);
      var dom = this.dom;
      var out = [];
    
      for (var i = 0, len = this.length; i < len; i++) {
        out.push(fn.call(dom(this[i]), this[i], i));
      }
    
      return this.dom(out);
    };
    
    /**
     * Select all values that return a truthy value of `fn(val, i)`.
     *
     *    inputs.select(function(input){
     *      return input.type == 'password'
     *    })
     *
     *  With a property:
     *
     *    inputs.select('type == password')
     *
     * @param {Function|String} fn
     * @return {List} self
     * @api public
     */
    
    exports.filter =
    exports.select = function(fn){
      fn = toFunction(fn);
      var dom = this.dom;
      var out = [];
      var val;
    
      for (var i = 0, len = this.length; i < len; i++) {
        val = fn.call(dom(this[i]), this[i], i);
        if (val) out.push(this[i]);
      }
    
      return this.dom(out);
    };
    
    /**
     * Reject all values that return a truthy value of `fn(val, i)`.
     *
     * Rejecting using a callback:
     *
     *    input.reject(function(user){
     *      return input.length < 20
     *    })
     *
     * Rejecting with a property:
     *
     *    items.reject('password')
     *
     * Rejecting values via `==`:
     *
     *    data.reject(null)
     *    input.reject(file)
     *
     * @param {Function|String|Mixed} fn
     * @return {List}
     * @api public
     */
    
    exports.reject = function(fn){
      var out = [];
      var len = this.length;
      var val, i;
    
      if ('string' == typeof fn) fn = toFunction(fn);
    
      if (fn) {
        for (i = 0; i < len; i++) {
          val = fn.call(dom(this[i]), this[i], i);
          if (!val) out.push(this[i]);
        }
      } else {
        for (i = 0; i < len; i++) {
          if (this[i] != fn) out.push(this[i]);
        }
      }
    
      return this.dom(out);
    };
    
    /**
     * Return a `List` containing the element at `i`.
     *
     * @param {Number} i
     * @return {List}
     * @api public
     */
    
    exports.at = function(i){
      return this.dom(this[i]);
    };
    
    /**
     * Return a `List` containing the first element.
     *
     * @param {Number} i
     * @return {List}
     * @api public
     */
    
    exports.first = function(){
      return this.dom(this[0]);
    };
    
    /**
     * Return a `List` containing the last element.
     *
     * @param {Number} i
     * @return {List}
     * @api public
     */
    
    exports.last = function(){
      return this.dom(this[this.length - 1]);
    };
    
    /**
     * Mixin the array functions
     */
    
    [
      'push',
      'pop',
      'shift',
      'splice',
      'unshift',
      'reverse',
      'sort',
      'toString',
      'concat',
      'join',
      'slice'
    ].forEach(function(method) {
      exports[method] = function() {
        return proto[method].apply(this.toArray(), arguments);
      };
    });
    
    
    });
    require.register("dom/lib/manipulate.js", function(exports, require, module){
    /**
     * Module Dependencies
     */
    
    var value = require('value');
    var css = require('css');
    
    /**
     * Return element text.
     *
     * @param {String} str
     * @return {String|List}
     * @api public
     */
    
    exports.text = function(str) {
      if (1 == arguments.length) {
        return this.forEach(function(el) {
          var node = document.createTextNode(str);
          el.textContent = '';
          el.appendChild(node);
        });
      }
    
      var out = '';
      this.forEach(function(el) {
        out += getText(el);
      });
    
      return out;
    };
    
    /**
     * Get text helper from Sizzle.
     *
     * Source: https://github.com/jquery/sizzle/blob/master/src/sizzle.js#L914-L947
     *
     * @param {Element|Array} el
     * @return {String}
     */
    
    function getText(el) {
      var ret = '';
      var type = el.nodeType;
      var node;
    
      switch(type) {
        case 1:
        case 9:
        case 11:
          if ('string' == typeof el.textContent) return el.textContent;
          for (el = el.firstChild; el; el = el.nextSibling) ret += text(el);
          break;
        case 3:
        case 4:
          return el.nodeValue;
        default:
          while (node = el[i++]) {
            ret += getText(node);
          }
      }
    
      return ret;
    }
    
    /**
     * Return element html.
     *
     * @return {String} html
     * @api public
     */
    
    exports.html = function(html) {
      if (1 == arguments.length) {
        return this.forEach(function(el) {
          el.innerHTML = html;
        });
      }
    
      // TODO: real impl
      return this[0] && this[0].innerHTML;
    };
    
    /**
     * Get and set the css value
     *
     * @param {String|Object} prop
     * @param {Mixed} val
     * @return {Mixed}
     * @api public
     */
    
    exports.css = function(prop, val) {
      // getter
      if (!val && 'object' != typeof prop) {
        return css(this[0], prop);
      }
      // setter
      this.forEach(function(el) {
        css(el, prop, val);
      });
    
      return this;
    };
    
    /**
     * Prepend `val`.
     *
     * From jQuery: if there is more than one target element
     * cloned copies of the inserted element will be created
     * for each target after the first.
     *
     * @param {String|Element|List} val
     * @return {List} self
     * @api public
     */
    
    exports.prepend = function(val) {
      var dom = this.dom;
    
      this.forEach(function(target, i) {
        dom(val).forEach(function(selector) {
          selector = i ? selector.cloneNode(true) : selector;
          if (target.children.length) {
            target.insertBefore(selector, target.firstChild);
          } else {
            target.appendChild(selector);
          }
        });
      });
    
      return this;
    };
    
    /**
     * Append `val`.
     *
     * From jQuery: if there is more than one target element
     * cloned copies of the inserted element will be created
     * for each target after the first.
     *
     * @param {String|Element|List} val
     * @return {List} self
     * @api public
     */
    
    exports.append = function(val) {
      var dom = this.dom;
    
      this.forEach(function(target, i) {
        dom(val).forEach(function(el) {
          el = i ? el.cloneNode(true) : el;
          target.appendChild(el);
        });
      });
    
      return this;
    };
    
    /**
     * Insert self's `els` after `val`
     *
     * From jQuery: if there is more than one target element,
     * cloned copies of the inserted element will be created
     * for each target after the first, and that new set
     * (the original element plus clones) is returned.
     *
     * @param {String|Element|List} val
     * @return {List} self
     * @api public
     */
    
    exports.insertAfter = function(val) {
      var dom = this.dom;
    
      this.forEach(function(el) {
        dom(val).forEach(function(target, i) {
          if (!target.parentNode) return;
          el = i ? el.cloneNode(true) : el;
          target.parentNode.insertBefore(el, target.nextSibling);
        });
      });
    
      return this;
    };
    
    /**
     * Append self's `el` to `val`
     *
     * @param {String|Element|List} val
     * @return {List} self
     * @api public
     */
    
    exports.appendTo = function(val) {
      this.dom(val).append(this);
      return this;
    };
    
    /**
     * Replace elements in the DOM.
     *
     * @param {String|Element|List} val
     * @return {List} self
     * @api public
     */
    
    exports.replace = function(val) {
      var self = this;
      var list = this.dom(val);
    
      list.forEach(function(el, i) {
        var old = self[i];
        var parent = old.parentNode;
        if (!parent) return;
        el = i ? el.cloneNode(true) : el;
        parent.replaceChild(el, old);
      });
    
      return this;
    };
    
    /**
     * Empty the dom list
     *
     * @return self
     * @api public
     */
    
    exports.empty = function() {
      return this.forEach(function(el) {
        el.textContent = '';
      });
    };
    
    /**
     * Remove all elements in the dom list
     *
     * @return {List} self
     * @api public
     */
    
    exports.remove = function() {
      return this.forEach(function(el) {
        var parent = el.parentNode;
        if (parent) parent.removeChild(el);
      });
    };
    
    /**
     * Return a cloned dom list with all elements cloned.
     *
     * @return {List}
     * @api public
     */
    
    exports.clone = function() {
      var out = this.map(function(el) {
        return el.cloneNode(true);
      });
    
      return this.dom(out);
    };
    
    });
    require.register("dom/lib/classes.js", function(exports, require, module){
    /**
     * Module Dependencies
     */
    
    var classes = require('classes');
    
    /**
     * Add the given class `name`.
     *
     * @param {String} name
     * @return {List} self
     * @api public
     */
    
    exports.addClass = function(name){
      return this.forEach(function(el) {
        el._classes = el._classes || classes(el);
        el._classes.add(name);
      });
    };
    
    /**
     * Remove the given class `name`.
     *
     * @param {String|RegExp} name
     * @return {List} self
     * @api public
     */
    
    exports.removeClass = function(name){
      return this.forEach(function(el) {
        el._classes = el._classes || classes(el);
        el._classes.remove(name);
      });
    };
    
    /**
     * Toggle the given class `name`,
     * optionally a `bool` may be given
     * to indicate that the class should
     * be added when truthy.
     *
     * @param {String} name
     * @param {Boolean} bool
     * @return {List} self
     * @api public
     */
    
    exports.toggleClass = function(name, bool){
      var fn = 'toggle';
    
      // toggle with boolean
      if (2 == arguments.length) {
        fn = bool ? 'add' : 'remove';
      }
    
      return this.forEach(function(el) {
        el._classes = el._classes || classes(el);
        el._classes[fn](name);
      })
    };
    
    /**
     * Check if the given class `name` is present.
     *
     * @param {String} name
     * @return {Boolean}
     * @api public
     */
    
    exports.hasClass = function(name){
      var el;
    
      for(var i = 0, len = this.length; i < len; i++) {
        el = this[i];
        el._classes = el._classes || classes(el);
        if (el._classes.has(name)) return true;
      }
    
      return false;
    };
    
    });
    require.register("dom/lib/attributes.js", function(exports, require, module){
    /**
     * Module Dependencies
     */
    
    var value = require('value');
    
    /**
     * Set attribute `name` to `val`, or get attr `name`.
     *
     * @param {String} name
     * @param {String} [val]
     * @return {String|List} self
     * @api public
     */
    
    exports.attr = function(name, val){
      // get
      if (1 == arguments.length) {
        return this[0] && this[0].getAttribute(name);
      }
    
      // remove
      if (null == val) {
        return this.removeAttr(name);
      }
    
      // set
      return this.forEach(function(el){
        el.setAttribute(name, val);
      });
    };
    
    /**
     * Remove attribute `name`.
     *
     * @param {String} name
     * @return {List} self
     * @api public
     */
    
    exports.removeAttr = function(name){
      return this.forEach(function(el){
        el.removeAttribute(name);
      });
    };
    
    /**
     * Set property `name` to `val`, or get property `name`.
     *
     * @param {String} name
     * @param {String} [val]
     * @return {Object|List} self
     * @api public
     */
    
    exports.prop = function(name, val){
      if (1 == arguments.length) {
        return this[0] && this[0][name];
      }
    
      return this.forEach(function(el){
        el[name] = val;
      });
    };
    
    /**
     * Get the first element's value or set selected
     * element values to `val`.
     *
     * @param {Mixed} [val]
     * @return {Mixed}
     * @api public
     */
    
    exports.val =
    exports.value = function(val){
      if (0 == arguments.length) {
        return this[0]
          ? value(this[0])
          : undefined;
      }
    
      return this.forEach(function(el){
        value(el, val);
      });
    };
    
    });
    require.register("dom/lib/events.js", function(exports, require, module){
    /**
     * Module Dependencies
     */
    
    var events = require('event');
    var delegate = require('delegate');
    
    /**
     * Bind to `event` and invoke `fn(e)`. When
     * a `selector` is given then events are delegated.
     *
     * @param {String} event
     * @param {String} [selector]
     * @param {Function} fn
     * @param {Boolean} capture
     * @return {List}
     * @api public
     */
    
    exports.on = function(event, selector, fn, capture){
      if ('string' == typeof selector) {
        return this.forEach(function (el) {
          fn._delegate = delegate.bind(el, selector, event, fn, capture);
        });
      }
    
      capture = fn;
      fn = selector;
    
      return this.forEach(function (el) {
        events.bind(el, event, fn, capture);
      });
    };
    
    /**
     * Unbind to `event` and invoke `fn(e)`. When
     * a `selector` is given then delegated event
     * handlers are unbound.
     *
     * @param {String} event
     * @param {String} [selector]
     * @param {Function} fn
     * @param {Boolean} capture
     * @return {List}
     * @api public
     */
    
    exports.off = function(event, selector, fn, capture){
      if ('string' == typeof selector) {
        return this.forEach(function (el) {
          // TODO: add selector support back
          delegate.unbind(el, event, fn._delegate, capture);
        });
      }
    
      capture = fn;
      fn = selector;
    
      return this.forEach(function (el) {
        events.unbind(el, event, fn, capture);
      });
    };
    
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    require.alias("component-event/index.js", "dom/deps/event/index.js");
    require.alias("component-event/index.js", "event/index.js");
    
    require.alias("component-delegate/index.js", "dom/deps/delegate/index.js");
    require.alias("component-delegate/index.js", "delegate/index.js");
    require.alias("component-matches-selector/index.js", "component-delegate/deps/matches-selector/index.js");
    require.alias("component-query/index.js", "component-matches-selector/deps/query/index.js");
    
    require.alias("component-event/index.js", "component-delegate/deps/event/index.js");
    
    require.alias("component-domify/index.js", "dom/deps/domify/index.js");
    require.alias("component-domify/index.js", "domify/index.js");
    
    require.alias("component-classes/index.js", "dom/deps/classes/index.js");
    require.alias("component-classes/index.js", "classes/index.js");
    require.alias("component-indexof/index.js", "component-classes/deps/indexof/index.js");
    
    require.alias("component-css/index.js", "dom/deps/css/index.js");
    require.alias("component-css/lib/css.js", "dom/deps/css/lib/css.js");
    require.alias("component-css/lib/prop.js", "dom/deps/css/lib/prop.js");
    require.alias("component-css/lib/swap.js", "dom/deps/css/lib/swap.js");
    require.alias("component-css/lib/style.js", "dom/deps/css/lib/style.js");
    require.alias("component-css/lib/hooks.js", "dom/deps/css/lib/hooks.js");
    require.alias("component-css/lib/styles.js", "dom/deps/css/lib/styles.js");
    require.alias("component-css/lib/vendor.js", "dom/deps/css/lib/vendor.js");
    require.alias("component-css/lib/support.js", "dom/deps/css/lib/support.js");
    require.alias("component-css/lib/computed.js", "dom/deps/css/lib/computed.js");
    require.alias("component-css/index.js", "dom/deps/css/index.js");
    require.alias("component-css/index.js", "css/index.js");
    require.alias("visionmedia-debug/index.js", "component-css/deps/debug/index.js");
    require.alias("visionmedia-debug/debug.js", "component-css/deps/debug/debug.js");
    
    require.alias("ianstormtaylor-to-camel-case/index.js", "component-css/deps/to-camel-case/index.js");
    require.alias("ianstormtaylor-to-space-case/index.js", "ianstormtaylor-to-camel-case/deps/to-space-case/index.js");
    require.alias("ianstormtaylor-to-no-case/index.js", "ianstormtaylor-to-space-case/deps/to-no-case/index.js");
    
    require.alias("component-within-document/index.js", "component-css/deps/within-document/index.js");
    
    require.alias("component-css/index.js", "component-css/index.js");
    require.alias("component-value/index.js", "dom/deps/value/index.js");
    require.alias("component-value/index.js", "dom/deps/value/index.js");
    require.alias("component-value/index.js", "value/index.js");
    require.alias("component-type/index.js", "component-value/deps/type/index.js");
    
    require.alias("component-value/index.js", "component-value/index.js");
    require.alias("component-query/index.js", "dom/deps/query/index.js");
    require.alias("component-query/index.js", "query/index.js");
    
    require.alias("component-matches-selector/index.js", "dom/deps/matches-selector/index.js");
    require.alias("component-matches-selector/index.js", "matches-selector/index.js");
    require.alias("component-query/index.js", "component-matches-selector/deps/query/index.js");
    
    require.alias("yields-traverse/index.js", "dom/deps/traverse/index.js");
    require.alias("yields-traverse/index.js", "dom/deps/traverse/index.js");
    require.alias("yields-traverse/index.js", "traverse/index.js");
    require.alias("component-matches-selector/index.js", "yields-traverse/deps/matches-selector/index.js");
    require.alias("component-query/index.js", "component-matches-selector/deps/query/index.js");
    
    require.alias("yields-traverse/index.js", "yields-traverse/index.js");
    require.alias("component-trim/index.js", "dom/deps/trim/index.js");
    require.alias("component-trim/index.js", "trim/index.js");
    
    require.alias("yields-isArray/index.js", "dom/deps/isArray/index.js");
    require.alias("yields-isArray/index.js", "isArray/index.js");
    
    require.alias("component-to-function/index.js", "dom/deps/to-function/index.js");
    require.alias("component-to-function/index.js", "to-function/index.js");
    require.alias("component-props/index.js", "component-to-function/deps/props/index.js");
    require.alias("component-props/index.js", "component-to-function/deps/props/index.js");
    require.alias("component-props/index.js", "component-props/index.js");if (typeof exports == "object") {
      module.exports = require("dom");
    } else if (typeof define == "function" && define.amd) {
      define(function(){ return require("dom"); });
    } else {
      this["dom"] = require("dom");
    }})();